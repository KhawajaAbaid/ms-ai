# Input
pop_size
n
stop
W
w1 v1
w2 v2
w3 v3
w4 v4
w5 v5
w6 v6
.. ..